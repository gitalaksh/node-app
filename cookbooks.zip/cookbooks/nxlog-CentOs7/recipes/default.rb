#
# Cookbook:: nxlog-CentOs7
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.

yum_package 'wget' do
  action :install
end

yum_package 'bzip2' do
  action :install
end

bash 'Install-nxlog-pkg' do
   user 'root'
   cwd '/tmp'
   code <<-EOH
   wget https://github.com/gitalaksh/test/raw/master/nxlog-trial-5.3.6735_rhel7_x86_64.tar.bz2 #### Download the tar file and put it somewhere you can pull/download
   tar -jxvf  nxlog-trial-5.3.6735_rhel7_x86_64.tar.bz2
   export NXLOG_USER=nxlog2
   export NXLOG_GROUP=nxlog2
   wget   https://gitlab.com/nxlog-public/contrib/-/blob/master/PGP-public-key/nxlog-pubkey.asc
   yum install -y epel-release
   yum install -y nxlog-trial-5.3.6735_rhel7_x86_64.rpm
   cd 
   /opt/nxlog/bin/nxlog -v
   service nxlog start
   EOH
end
