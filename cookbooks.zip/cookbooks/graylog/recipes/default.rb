#
# Cookbook:: graylog
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.

bash 'update' do
   user 'root'
   code <<-EOH
     apt-get update -y
    EOH
end

apt_package 'openjdk-8-jdk' do
  action :install
end

bash 'elastsearch' do
  user 'root'
  cwd '/tmp'
  code <<-EOH
    wget -q https://artifacts.elastic.co/GPG-KEY-elasticsearch -O myKey
    apt-key add myKey
    echo "deb https://artifacts.elastic.co/packages/oss-7.x/apt stable main" | sudo tee -a /etc/apt/sources.list.d/elastic-7.x.list
    apt-get update && sudo apt-get install elasticsearch-oss
    echo "cluster.name: graylog" >> /etc/elasticsearch/elasticsearch.yml 
    echo "action.auto_create_index: false" >> /etc/elasticsearch/elasticsearch.yml
    EOT
    systemctl daemon-reload
    systemctl enable elasticsearch.service
    systemctl restart elasticsearch.service
  EOH
end

apt_package 'mongodb-server' do
  action :install
end

bash 'graylogrepo-download' do
  user 'root'
  cwd '/tmp'
  code <<-EOH
  wget https://packages.graylog2.org/repo/packages/graylog-4.0-repository_latest.deb
  dpkg -i graylog-4.0-repository_latest.deb
  apt-get update && sudo apt-get install graylog-server
#  sed -i '/password_secret/c\password_secret = s7finps4RUosXOVcJ3B6TLCmXnIKaDwvrONHPKKsrtMQoGkkJt0dHbQGHrGsZEsR2GW3EWluCSd1HjCropPTE5tokahUFk6h' /etc/graylog/server/server.conf
#  sed -i '/root_password_sha2/c\root_password_sha2 = 8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918' /etc/graylog/server/server.conf
#  echo "http_bind_address = 0.0.0.0:9000" >> /etc/graylog/server/server.conf
#  ip=$(curl -s  wgetip.com); echo "http_external_uri = http://$ip:9000/" >> /etc/graylog/server/server.conf
  systemctl daemon-reload
  systemctl enable graylog-server.service
  systemctl start graylog-server.service
  EOH
end


