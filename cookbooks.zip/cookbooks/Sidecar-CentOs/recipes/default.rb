#
# Cookbook:: Sidecar-CentOs
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.

bash 'Install Sidecar' do
   user 'root'
   code <<-EOH
    rpm -Uvh https://packages.graylog2.org/repo/packages/graylog-sidecar-repository-1-2.noarch.rpm
    yum install  graylog-sidecar -y
    graylog-sidecar -service install
    
    systemctl start graylog-sidecar
    EOH
end

bash 'Configuer Sidecar' do
    user 'root'
    code <<-EOH
      sed -i '/server_url/d' /etc/graylog/sidecar/sidecar.yml
      sed -i '/server_api_token/d' /etc/graylog/sidecar/sidecar.yml
      sed -i '/node_id/d' /etc/graylog/sidecar/sidecar.yml
      echo 'server_url: "http://graylog-server-ip-or-domain:9000/api/"' >> /etc/graylog/sidecar/sidecar.yml ### replace "graylog-server-ip-or-domain" with gray-log server domain or ip
      echo 'server_api_token: "token"' >>  /etc/graylog/sidecar/sidecar.yml                                 ### replace "token" with actual token genrated by graylog server
      echo 'node_id: "file:/etc/graylog/sidecar/node-id"' >> /etc/graylog/sidecar/sidecar.yml
      echo 'list_log_files:                                                                                 ## replace files paths those you want to scan
               - "/var/log"                                                                                 
               - "/opt/app/log/"
	       - "/var/log/http/"' >> /etc/graylog/sidecar/sidecar.yml
      systemctl restart graylog-sidecar
    EOH
end        


 
