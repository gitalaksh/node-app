#
# Cookbook:: graylog-CentOs
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.

yum_package 'java-1.8.0-openjdk-headless.x86_64' do
  action :install
end

yum_repository 'mongodb-org.repo' do
  description 'mongodb-org.repo yum repository'
  baseurl 'https://repo.mongodb.org/yum/redhat/$releasever/mongodb-org/4.2/x86_64/'
  gpgkey 'https://www.mongodb.org/static/pgp/server-4.2.asc'
  action :create
end

yum_package 'mongodb-org' do
  action :install
end

bash 'start-mongo' do
   user 'root'
   code <<-EOH
      systemctl daemon-reload
      systemctl enable mongod.service
      systemctl start mongod.service
    EOH
end


yum_repository 'elasticsearch-7.x' do
  description 'elasticsearch-7.x yum repository'
  baseurl 'https://artifacts.elastic.co/packages/oss-7.x/yum'
  gpgkey 'https://artifacts.elastic.co/GPG-KEY-elasticsearch'
  action :create
end

yum_package 'elasticsearch-oss' do
  action :install
end

bash 'configure-elast' do
   user 'root'
   code <<-EOH
      sed -i '/cluster.name/d' /etc/elasticsearch/elasticsearch.yml
      sed -i '/action.auto_create_index/d' /etc/elasticsearch/elasticsearch.yml
      echo "cluster.name: graylog" >> /etc/elasticsearch/elasticsearch.yml
      echo "action.auto_create_index: false" >> /etc/elasticsearch/elasticsearch.yml 
    EOH
end

bash 'start-elast' do
   user 'root'
   code <<-EOH
      systemctl daemon-reload
      systemctl enable elasticsearch.service
      systemctl restart elasticsearch.service
    EOH
end


bash 'setup-graylog' do
   user 'root'
   cwd '/tmp'
   code <<-EOH
    rpm -Uvh https://packages.graylog2.org/repo/packages/graylog-4.0-repository_latest.rpm
    yum install graylog-server -y
    systemctl daemon-reload
    systemctl enable graylog-server.service
    systemctl start graylog-server.service
    EOH
end

bash 'configure-graylog' do
   user 'root'
   code <<-EOH
   sed -i '/password_secret/d' /etc/graylog/server/server.conf
   sed -i '/root_password_sha2/d' /etc/graylog/server/server.conf
   sed -i '/http_bind_address/d' /etc/graylog/server/server.conf
   sed -i '/http_external_uri/d' /etc/graylog/server/server.conf
   echo "password_secret = s7finps4RUosXOVcJ3B6TLCmXnIKaDwvrONHPKKsrtMQoGkkJt0dHbQGHrGsZEsR2GW3EWluCSd1HjCropPTE5tokahUFk6h" >> /etc/graylog/server/server.conf;
   echo "root_password_sha2 = 8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918" >> /etc/graylog/server/server.conf;
   echo "http_bind_address = 0.0.0.0:9000" >> /etc/graylog/server/server.conf;
   ip=$(curl -s  wgetip.com); echo "http_external_uri = http://$ip:9000/" >> /etc/graylog/server/server.conf;
   systemctl restart graylog-server
   EOH
end
